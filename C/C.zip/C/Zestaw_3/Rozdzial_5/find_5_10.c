//Przekształcamy program wyszukiwania wierszy zawierających wzorzec
//z 4.1, by działał jak grep, czyli wzorzec był podawany jako pierwszy
//argum. w poleceniu wywołania programu:
#include <stdio.h>
#include <string.h>

#define MAXLINE 1000

int getline(char *line, int max)

//find: wypisz wiersze pasujące do wzorca z 1 argum.
/*main(int argc, char *argv[])
{
	char line[MAXLINE];
	int found = 0;
	
	if(argc != 2)
		printf("Format wywołania: find wzorzec\n");
	else
		while(getline(line, MAXLINE) > 0)
			if(strstr(line, argv[1]) != NULL){
			//strstr zwraca wskaźnik do pierwszego wystąpienia
			//tekstu z t w s lub NULL, gdy nie znalazł;
				printf("%s", line);
				found++;
				}
	return found;
}
*/

//Można rozszerzyć działanie programu przez przełączniki(opcje) wg konwencji
//Unix tj. -x(except - sygnalizowanie odwrotnego działania programu) 
//oraz -n(number -oznacza żądanie numerowania wierszy) 
//wywołujemy wg. find -x -n wzorzec lub zgrupowany przełącznik -nx
#include <stdio.h>
#include <string.h>

#define MAXLINE 1000

int getline(char *line, int max);

//find: wypisz wiersze pasujące do wzorca z 1 obowiązkowego arg.
main(int argc, char *argv[])
{
	char line[MAXLINE];
	long lineno=0;
	int c, except=0, number=0, found=0;
	
	while(--argc>0 && (*++argv)[0]=='-')
		while(c=*++argv[])
			switch(c){
				case 'x':
					except=1;
					break;
				case 'n':
					number=1;
					break;
				default:
					printf("find: nieznana opcja %c\n", c);
					argc=0;
					found=-1;
					break;
				}
	if(argc!=1)
		printf("Format wywołania: find -x -n wzorzec\n");
	else
		while(getline(line, MAXLINE) >0){
			lineno++;
			if((strstr(line, *argv) != NULL) != except){
				if(number)
					printf("%ld: ", lineno);
				printf("%s", line);
				found++
				}
			}
	return found;
}
