//strcpy: skopiuj t do s; wersja z indeksowanie tablic:
/*void mystrcpy(char *s, char *t)
{
	int i;
	
	i=0;
	while ((s[i]=t[i]) != '\0')
		i++;;	
}
*/

//strcpy: skopiuj t do s; wersja wskaźnikowa 1;
/*void mystrcpy(char *s, char *t)
{
	while((*s=*t) != '\0'){
		s++;
		t++;
		}
}
*/

//strcpy: skopiuj t do s; wersja wskaźnikowa pro:
/*void mystrcopy(char *s, char *t)
{
	while((*s++=*t++) != '\0')
		;
}
*/

//strcpy: skopiuj t do s; wersja wskaźnikowa pro+
void mystrcpy(char *s, char *t)
{
		while(*s++ = *t++)
		//korzystamy tu z faktu, że ptanie dla warunku pętli zawsze brzmi:
		//czy wart. wyrażenia jest zero?
			;
}
