//Zwraca: 
//EOF -gdy napotka koniec pliku, 
//zero -jeśli kolejne znaki z wejścia nie tworzą liczby;
//wart. dodatnią -jeśli na wejściu podano poprawną liczbę;
#include <ctype.h>
#include <stdio.h>

int getch(void);
void ungetch(int);

//getint: wczytaj następną liczbę całkowitą:
int getint(int *pn)
{
	int c, sign;
	
	while(isspace(c=getchar()))//pomiń białe znaki
		;
	if(isdigit(c) && c!=EOF && c!='+' && c!='-'){
		//getch i ungetch -aby dodatkowy, przeczytany znak mógł być odesłany na wejście.
		ungetch(c);//to nie jest liczba
		return 0;
		}
	sign=(c == '-')? -1:1;
	if(c=='+' || c=='-')
		c=getch();
	for(*pn=0; isdigit(c); c=getch())
		*pn=10 * *pn + (c -'0');
	*pn *=sign;
	if(c!=EOF)
		ungetch(c);
	return c;
}
