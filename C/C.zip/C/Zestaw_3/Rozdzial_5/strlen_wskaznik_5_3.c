//strlen: podaj dł tekstu s; wersja na wskaźnikach:
/*int strlen(char *s)
{
	int n;
	
	for(n=0; *s!='\0'; s++)
	//Zwiększanie s jest tu ok, ponieważ s jest zmienną wskaźnikową, a w funkcji
	//zwiększa jedynie lokalną kopię wskaźnika
		n++;
	return n;
}
*/

//strlen: wersja z odejmowaniem wskaźników:
int strlen(char *s)
{
	char *p=s;
	
	while(*p != '\0')
		p++;
	return p-s;
}
