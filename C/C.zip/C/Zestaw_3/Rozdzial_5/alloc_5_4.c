#define ALLOCSIZE 1000//rozmiar dostępnej pamięci;

static char allocbuf[ALLOCSIZE];//pamięć dla alloc
static char *allocp = allocbuf;//następna wolna pozycja;

char *alloc(int n)//podaj wskaźnik do n znaków
{
	if(allocbuf+ALLOCSIZE-allocp >= n){//wystarczy miejsca;
		allocp+=n;
		return allocp - n;//zwróć starą wartość allocp
		}
	else//za mało miejsca
		return 0;
}

void afree(char *p)//zwolnij pamięć wskazaną przez p;
{
	if(p>=allocbuf && p<allocbuf+ALLOCSIZE)
		allocp=p;
}
