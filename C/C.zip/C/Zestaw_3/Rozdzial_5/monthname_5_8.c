//month_name: podaj nazwę n-tego miesiąca;
char *month_name(int n)
{
	static char *name[]={
		"błędny miesiąc", "styczeń", "luty", "marzec", "kwiecień",
		"maj", "czerwiec", "lipiec", "sierpień", "wrzesień", 
		"październik", "listopad", "grudzień"
		};
	
	return(n<1 || n>12)? name[0]:name[n];
}
