#include "structs_6_2.c"

//ptinrect: zwróć 1, jeśli p należy do r, 0 jeśli nie:
int ptinrect(struct point p, struct rect r)
{
	return p.x>=r.pt1.x && p.x<r.pt2.x && p.y>=r.pt1.y && p.y<r.pt2.y;
}
