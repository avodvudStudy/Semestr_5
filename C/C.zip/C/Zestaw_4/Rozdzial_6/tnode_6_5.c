//Węzeł dla drzewa binarnego porównań leksykograficznych:
struct tnode{			//węzeł drzewa
	char *word;			//wskaźnik do słowa
	int count;			//licznik wystąpień
	struct tnode *left; //lewy potomek
	struct tnode *right; //prawy potomek
	};
