//
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h> //dla malloc
#include <stddef.h> //niby dla sizeof, ale chyba nie w tym rzecz.

//Węzeł dla drzewa binarnego porównań leksykograficznych:
struct tnode{			//węzeł drzewa
	char *word;			//wskaźnik do słowa
	int count;			//licznik wystąpień
	struct tnode *left; //lewy potomek
	struct tnode *right; //prawy potomek
	};

#define MAXWORD 100
struct tnode *addtree(struct tnode *, char *);
void treeprint(struct tnode *);
int getword(char *, int);

//zliczanie wystąpień słów:
int main(void)
{
	struct tnode *root; //wskaźnik do korzenia drzewa
	char word[MAXWORD];
	
	root=NULL;
	while(getword(word, MAXWORD) != EOF)
		if(isalpha(word[0]))
			root=addtree(root, word);
	treeprint(root);
	return 0;
}

struct tnode *talloc(void);
char *strdup(char *);

//adtree: dodaj węzeł dla w; szukaj w p lub poniżej p
struct tnode *addtree(struct tnode *p, char *w)
{
	int cond;
	
	if(p==NULL){ 		//w jest nowym słowem
		p=talloc(); 	//utwórz nowy węzeł
		p->word = strdup(w);
		p->count = 1;
		p->left = p->right = NULL;
		}
	else if((cond=strcmp(w, p->word))==0)	//powtórzone słowo:
		p->count++; 
	else if(cond<0) //mniejsze: do lewego poddrzewa:
		p->left = addtree(p->left, w);
	else //większe: do prawego poddrzewa
		p->right = addtree(p->right, w);
	return p;
}

//treeprint: wypisz uporządkowane drzewo p
void treeprint(struct tnode *p)
{
	if(p!=NULL){
		treeprint(p->left);
		printf("%4d%s\n", p->count, p->word);
		treeprint(p->right);
		}
}

//talloc: utwórz węzeł:
struct tnode *talloc(void)
{
	return (struct tnode *)malloc(sizeof(struct tnode));
}

//strdup: sporządź kopię s:
char *strdup(char *s)
{
	char *p;
	
	p=(char *)malloc(strlen(s)+1); //+1 dla '\0'
	if(p!=NULL)
		strcpy(p, s);
	return p;
}
