//Ogniwo łańcucha algorytmu przeszukiwania rozproszonego
struct nlist{//ogniwo łańcucha
	struct nlist *next; //następne ogniwo
	char *name; 		//definiowana nazwa
	char *defn;			//zastępujący ją tekst
	};
