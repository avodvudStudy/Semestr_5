//Funkcja pobiera następne "słowo" z wejścia, przy czym słowem jest
//zarówno cg. liter i cyfr zaczynający się od litery, jak i poj.
//nie biały znak. Jej wart funkc. jest pierwszy znak słowa lub EOF,
//po napotkaniu końca pliku, lub też sam znak, jeśli nie jest literą.
#include <stdio.h>
#include <string.h>
#include <ctype.h>

//getword: weź nast. słowo lub znak z wejścia
int getword(char *word, int lim)
{
	//kompletując znaki alfanumeryczne getword czyta o jeden za dużo,
	//więc stosujemy getch i ungetch
	int c, getch(void);
	void ungetch(int);
	char *w=word;
	
	while(isspace(c=getch()))
		;
	if(c!=EOF)
		*w++=c;
	if(!isalpha(c)){
		*w='\0';
		return c;
		}
	for(; --lim>0; w++)
		if(!isalnum(*w=getch())){
			ungetch(*w);
			break;
			}
	*w='\0';
	return word[0];
}
