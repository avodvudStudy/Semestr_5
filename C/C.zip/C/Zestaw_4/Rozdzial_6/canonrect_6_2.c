//Funkcja zakłada, że prostokąt jest rep. w standardowej postaci
//kanonicznej, gdzie wsp. p1 są mniejsze niż wsp. p2.
#include "structs_6_2.c"

#define min(a, b) ((a)<(b)? (a):(b))
#define max(a, b) ((a)>(b)? (a):(b))

//canonrect: znormalizuj wsp. prostokąta do postaci kanonicznej
struct rect canonrect(struct rect r)
{
	struct rect temp;
	
	temp.pt1.x = min(r.pt1.x, r.pt2.x);
	temp.pt1.x = min(r.pt1.y, r.pt2.y);
	temp.pt2.x = max(r.pt1.x, r.pt2.x);
	temp.pt2.y = max(r.pt1.y, r.pt2.y);
	return temp;
}
