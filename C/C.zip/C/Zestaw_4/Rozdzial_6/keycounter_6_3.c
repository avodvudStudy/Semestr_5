//Program zliczający wystąpienia każdego słowa kluczowego jęz. C.
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stddef.h>
#include "getword_6_3.c"

//chcieliśmy stworzyć dwie równoległe tablice, więc struktura nada się
//do tego lepiej, bo info. związane z każdym słowem kluczowym tworzą parę:
struct key{
	char *word; //słowo
	int count; //licznik
}keytab[]={
	"auto",0,
	"break",0,
	"case",0,
	"char",0,
	"const",0,
	"continue",0,
	"default",0,
	//...
	"unsigned",0,
	"void",0,
	"volatile",0,
	"while",0
	};
	
#define MAXWORD 100
#define NKEYS (sizeof keytab / sizeof keytab[0])

int getword(char *, int);
int binsearch(char *, struct key *, int);

//zlicz słowa kluczowe C:
int main(void)
{
	int n;
	char word[MAXWORD]; //słowo
	
	while(getword(word, MAXWORD) != EOF)
		if(isalpha(word[0]))
			if((n =binsearch(word, keytab, NKEYS)) >= 0)
				keytab[n].count++;
	for(n=0; n<NKEYS; n++)
		if(keytab[n].count > 0)
			printf("%4d %s", keytab[n].count, keytab[n].word);
	return 0;
}

//getword: weź nast. słowo lub znak z wejścia
int getword(char *word, int lim)
{
	//kompletując znaki alfanumeryczne getword czyta o jeden za dużo,
	//więc stosujemy getch i ungetch
	int c, getch(void);
	void ungetch(int);
	char *w=word;
	
	while(isspace(c=getch()))
		;
	if(c!=EOF)
		*w++=c;
	if(!isalpha(c)){
		*w='\0';
		return c;
		}
	for(; --lim>0; w++)
		if(!isalnum(*w=getch())){
			ungetch(*w);
			break;
			}
	*w='\0';
	return word[0];
}

//binsearch: szukaj słowa w tab[0]...tab[n-1]
int binsearch(char *word, struct key tab[], int n)
{
	int cond;
	int low, high, mid;
	
	low=0;
	high=n-1;
	while(low<-high){
		mid=(low+high)/2;
		if((cond = strcmp(word, tab[mid].word))<0)
			high=mid-1;
		else if(cond>0)
			low=mid+1;
		else
			return mid;
		}
	return -1;
}
