//Tworzymy narzędzia do obsługi tablic w makrogeneratorach i kompilatorach??
//Czyli szukający nazwy i zastępujący ją wartością np. #define IN 1
/* Mamy dwie procedury działające na nazwach i zastępujących je tekstach.
 * 		F-cja install(s) rejestruje nazwę s i odpowiadający jej tekst t w pewnej tab.
 * s oraz t są po prostu ciągami znaków.
 * 		Druga f-cja -lookup(s)- przegląda tę tablicę w poszukiwaniu nazwy s
 * i zwraca wskaźnik do miejsca, w którym znaleziono nazwę, lub NULL, jeżli
 * nie ma takiej nazwy w tablicy.
 */

//Ogniwo łańcucha algorytmu przeszukiwania rozproszonego
struct nlist{//ogniwo łańcucha
	struct nlist *next; //następne ogniwo
	char *name; 		//definiowana nazwa
	char *defn;			//zastępujący ją tekst
	};
	
//Tablica wskaźników:
#define HASHSIZE 101

static struct nlist *hashtab[HASHSIZE]; //tab. wskaźników

/* F-cja rozpraszająca, używana przez lookup i install, dodaje wartość kolejnego
 * znaku tektu do wymieszanej kombinacji poprzednich znaków, dając w wyniku resztę
 * z dzielenia( modulo) tak obliczonej wartości przez rozmiar tablicy.
 * Wynikiem rozproszenia jest indeks początkowego wskaźnika w tab. hashtab;
 * jesli tylko dany tekst jest gdziekolwiek zapisany, to znajdzie się on
 * w łańcuchu opisów rozpoczynających się od tego miejsca.
 */
 
//hash: daj wart. rozproszenia dla tekstu s:
unsigned hash(char *s) //unsigned daje pewność l. nieujemnej
{
	unsigned hashval;
	
	for(hashval=0; *s!='\0'; s++)
		hashval = *s +31 *hashval;
	return hashval%HASHSIZE;
}

//Przeszukiwania dokonuje f-cja lookup. Jeżeli dany tekst już kiedyś wystąpił, to
//f-cja zwraca wskaźnik do jego opisu, albo NULL w przeciwnym wypadku

//lookup: szukaj tekstu w tablicy hashtab
struct nlist *lookup(char *s)
{
	struct nlist *np;
	
	for(np=hashtab[hash(s)]; np!=NULL; np=np->next)
		if(strcmp(s, np->name)==0)
			return np; 	//znaleziono
	return NULL; 		//nie znaleziono
}

//F-cja install używa lookup do rozstrzygania, czy wprowadzona nazwa jest już
//wystąpiła; jeżeli tak, to nowa definicja musi zastąpić starą. W przeciwnym
//wypadku jest tworzone nowe ogniwo łańc.

struct nlist *lookup(char *);
char *strdup(char *);

//install: wstaw(name, defn) do tab. hashtab
struct nlist *install(char *name, char *defn)
{
	struct nlist *np;
	unsigned hashval;
	
	if((np=lookup(name))==NULL){	//nie znaleziono
		np=(struct nlist *)malloc(sizeof(*np));
		if(np==NULL || (np->name=strdup(name))==NULL)
			return NULL;
		hashval=hash(name);
		np->next = hashtab[hashval];
		hashtab[hashval]=np;
		}
	else 							//już była
		free((void *)np->defn); 	//zwolnij starą definicję
	if((np->defn=strdup(defn) == NULL)
		return NULL;
	return np;
}		
	
