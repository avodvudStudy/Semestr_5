//struktury do podrozdz. 6.2
struct point{
	int x;
	int y;
	};
	
struct rect{
	struct point pt1;
	struct point pt2;
	};

