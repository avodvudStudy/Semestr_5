#include "structs_6_2.c"

//addpoint: dodaj dwa pkt:
struct point addpoint(struct point p1, struct point p2)
{
	p1.x += p2.x;
	p1.y += p2.y;
	return p1;
}
