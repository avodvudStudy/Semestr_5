#include <stdio.h>

//Tylko_nieujemne: przetwarza tylko el. nieujemne, ujemne są pomijane
for(i=0, i<n, i++){
	if(a[i]<0)//pomiń el ujemny
		continue;
	... 	//przetwarzaj el. nieujemny
	}
