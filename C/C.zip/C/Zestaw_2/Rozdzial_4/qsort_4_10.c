//Qsort: uporządkuj v[left]...v[right] rosnąco:
void myqsort(int v[], int left, int right)
{
	int i, last;
	void swap(int v[], int i, int j);
	
	if(left>=right)//nic nie rób, jeśli tablica zawiera mniej niż 2 el.
		return;
	swap(v, left, (left+right)/2);//el. podziału
	last=left;//przesuń do v[0]
	for(i=left+1; i<=right; i++)//podział
		if(v[i]<v[left])
			swap(v, ++last, i);
	swap(v, left, last);//odtwórz el. podziału
	myqsort(v, left, last-1);
	myqsort(v, last+1, right);
}

//Swap: zamień miejscami v[i] z v[j]
void swap(int v[], int i, int j)
{
	int temp;
	
	temp=v[i];
	v[i]=v[j];
	v[j]=temp;
}
