#include <stdio.h>
#include <stdlib.h> //dla atof()

#define MAXOP 100 	//max. długość operandu lub operatora;
#define NUMBER '0' 	//sygnał znalezienia liczby;

int getop(char []);
void push(double);
double pop(void);

//Kalkulator wg Odwrotnej Notacji Polskiej:
main()
{
	int type;
	double op2;
	char s[MAXOP];
	
	while((type=getop(s)) != EOF){
		switch(type){
			case NUMBER:
				push(atof(s));
				break;
			case '+':
				push(pop() + pop());
				break;
			case '*':
				push(pop() * pop());
				break;
			case '-':
				op2=pop();
				push(pop() - op2);
				break;
			case '/':
				op2=pop();
				if(op2!=0.0)
					push(pop()/op2);
				else
					printf("Błąd: dzielenie przez 0\n");
				break;
			case '/n':
				printf("\t%.8g\n", pop());
				break;
			default:
				printf("Błąd: nieznane polecenie %s\n", s);
				break;
			}
		}
	return 0;
}
/////////////////////BUDOWA STOSU:
#define MAXVAL 100	//max. głębokość stosu;

int sp=0;//następne wolne miejsce na stosie;
double val[MAXVAL]; //stos wartości;

//Push: wstaw f na stos:
void push(double f)
{
	if(sp<MAXVAL)
		val[sp++]=f;
	else
		printf("Błąd: pełen stos; nie można umieścić %g\n", f);
}

//Pop: zdejmij i zwróć wartość ze szczytu stosu:
double pop(void)
{
	if(sp>0)
		return val[--sp];
	else{
		printf("Błąd: pusty stos\n");
		return 0.0;
		}
}
////////////////////GETOP:
#include <ctype.h>

int getch(void);
void ungetch(int);

//Getop: pobierz następny operator lub argument:
int getop(char s[])
{
	int i,c;
	
	while((s[0]=c=getch()) == ' ' || c=='\t')
		;
	s[1]='\0';
	if(!isdigit(c) && c!='.')
		return c;//to nie liczba
	i=0;
	if(isdigit(c)) //buduj część całkowitą
		while(isdigit(s[++i]=c=getch()))
			;
	if(c=='.')//buduj ułamek
		while(isdigit(s[++i]=c=getch()))
			;
	s[i]='\0';
	if(c!=EOF)
		ungetch(c);
	return NUMBER;
}
////GETCH I UNGETCH: chronią, by program nie pobrał przez przypadek o jeden znak za dużo
#define BUFSIZE 100//maks. rozmiar bufora;

char buf[BUFSIZE];//bufor na zwroty z ungetch;
int bufp=0;//następne wolne miejsce w buforze;

int getch(void)//weź znak, być może oddany na wejście:
{
	return(bufp>0)? buf[--bufp]:getchar();
}

void getch(int c)//oddaj znak z powrotem na wejście
{
	if(bufp>=BUFSIZE)
		printf("ungetch: za wiele zwrotów\n");
	else
		buf[bufp++]=c;
		
}

