#include <stdio.h>

//MyStrlen: podaj długość tekstu w s
int mystrlen(char s[])
{
	int i;
	
	i=0;
	while(s[i] != '\0')
		++i;
	return i;
}
