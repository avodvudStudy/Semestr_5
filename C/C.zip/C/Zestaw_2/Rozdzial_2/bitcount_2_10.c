#include <stdio.h>

//Bitcount: policz bity 1 w x;
int bicount(unsigned x) //zadeklarowanie unsigned daje pewność, że podczas
{						//przesuwania w prawo, niezależnie od maszyny, 
	int b;				//zwolnione bity zostaną zapełnione zerami, nie zaś
						//bitami znaku liczby;
	for(b=0; x!=0; x>>=1)
		if(x & 01)
			b++;
	return b;
}
