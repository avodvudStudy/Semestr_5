#include <stdio.h>

//Atoi: zamień s na wartość całkowitą:
int atoi(char s[])
{
	int i,n;
	
	n=0;
	for(i=0; s[i] >= '0' && s[i] <= '9'; ++i)
		n=10*n+(s[i]-'0'); //s[i] -'0' daje numeryczną wartość cyfry
	return n;			  //zawartej w s[i], gdyż wartości kodów znaków 
						 //'0', '1' itd. tworzą ciąg rosnących liczb całkowitych.
}
