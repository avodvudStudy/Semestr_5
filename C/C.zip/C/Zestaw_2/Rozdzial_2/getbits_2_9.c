#include <stdio.h>

//Getbits: daj n bitów x od pozycji p
//np. getbits(x,4,3) zwraca trzy bity - z pozycji 4,3,2 
//dosunięte do prawej strony wyniku;
unsigned getbits(unsigned x, int p, int n)
{
	return(x>>(p+1-n)) & ~(~0<<n);
	//x>>(p+1-n) dosuwa wybrane pole do prawego końca słowa;
	//zapis ~0 oznacza same jedynki; 
	//przesunięcie ich w lewo o n pozycji bitowych
	//(~0<<n) tworzy maskę z zerami na prawych skrajnych n bitach
	//dopełnienie jedynkowe tej maski za pomocą operatora 
	// -tworzy maskę zbudowaną z jedynek na prawych skrajnych n bitach;
	
}
