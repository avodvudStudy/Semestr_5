#include <stdio.h>

//Zlicz cyfry, białe znaki, inne
main()
{
	int c, i, nwhite, nother;
	int ndigit[10];
	
	nwhite=nother=0;
	for(i=0; i<10; ++i)
		ndigit[i]=0;
	
	while((c=getchar()) != EOF)
		if( c>='0' && c<='9') //czy znak jest cyfrą?
			++ndigit[c - '0'];
		else if(c==' ' || c=='\n' || c=='\t')
			++nwhite;
		else
			++nother;
	printf("cyfry= ");
	for(i=0; i<10; ++i)
		printf("%d", ndigit[i]);
	printf(",białeznaki= %d, inne= %d\n", nwhite, nother);
}
