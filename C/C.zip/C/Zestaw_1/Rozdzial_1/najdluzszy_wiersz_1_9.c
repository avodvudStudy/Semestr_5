#include <stdio.h>

#define MAXLINE 1000 //maks. rozmiar wiersza

/*int mygetline(char line[], int maxline);
void copy(char to[], char from[]);

//Wypisz najdłuższy wiersz
int main()
{
	int len; 				//długość bieżącego wiersza
	int max; 				//poprzednia maks. długość
	char line[MAXLINE];		//bieżący wiersz z wejścia
	char longest[MAXLINE]; 	//przechowywany maks. wiersz
	
	max=0;
	while((len=mygetline(line, MAXLINE)>0))
		if(len>max){
			max=len;
			copy(longest, line);
			}
	if(max>0) //znaleziono wiersz
		printf("%s", longest);
	return 0;
}
//Mygetline: wczytaj wiersz do s, podaj jego długość
int mygetline(char s[], int lim)
{
	int c, i;
	
	for(i=0; i<lim-1 && (c=getchar())!=EOF && c!='\n'; ++i)
		s[i]=c;
	if(c=='\n'){
		s[i]=c;
		++i;
		}
	s[i]='\0'; //wstawiamy znak końca cg. znaków; konwencja C; nie jest częścią normalnego teksu
	return i;
}
//Copy: przepisz from do to; to musi być dostatecznie duże
void copy(char to[], char from[])
{
	int i;
	
	i=0;
	while((to[i]=from[i])!='\0')
		++i;
}
*/

//Wypisz najdłuższy wiersz; wersja 2 - zmienne zewnętrzne;
int max; 				//poprzednia maks. długość
char line[MAXLINE];		//bieżący wiersz z wejścia
char longest[MAXLINE]; 	//przechowywany maks. wiersz

int mygetline(void); //należy użyć void, zamiast zostawić listę parametrów pustą
void copy(void);
//wypisz najdłuższy wiersz; wersja specjalna
int main()
{
	int len; //długość bieżącego wiersza
	extern int max;
	extern char longest[];
	
	max=0;
	while((len=mygetline())>0)
		if(len>max){
			max=len;
			copy();
			}
	if(max>0) //znaleziono wiersz
		printf("%s", longest);
	return 0;
}

//mygetline: wersja specjalna
int mygetline(void)
{
	int c,i;
	extern char line[], longest[];
	
	for(i=0; i<MAXLINE-1 && (c=getchar())!=EOF && c!='\n'; ++i)
		line[i]=c;
	if(c=='\n'){
		line[i]=c;
		++i;
		}
	line[i]='\0';
	return i;
}
//copy: wersja specjalna
void copy(void)
{
	int i;
	extern char line[], longest[];
	
	i=0;
	while((longest[i]=line[i])!='\0')
		++i;
}
