#include <stdio.h>

/*//Przepisz wejście na wyjście; wersja 1
main()
{
	int c; //typ int zamiast char, aby zmienna mogła pomieścić także zmienną EOF!
	
	c=getchar();
	while(c!=EOF){
		putchar(c);
		c=getchar();
		} 
	}*/

/*//Przepisz wejście na wyjście; wersja 2
main()
{
	int c;
	
	while( (c=getchar()) != EOF)
	// nawiasy są potrzebne, gdyż priorytrt != jest wyższy niź operatora przypisania = 
		putchar(c);
	} */
	
	

	

	
