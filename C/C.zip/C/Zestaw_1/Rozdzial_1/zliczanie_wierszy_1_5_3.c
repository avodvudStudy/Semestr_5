#include <stdio.h>

//Zlicz wiesze wejściowe - zlicz znaki nowego wiersza
main()
{
	int c, nl;
	
	nl=0;
	while( (c=getchar()) != EOF)
		if(c=='\n') // !'/n' jest jednym znakiem, a "/n" ciągiem znaków zawierającym jeden znak!
			++nl;
	printf("%d\n", nl);
		
	
}
